### Enable access to the cycle counter

For accurate benchmarking on Cortex-A72, we make use of the performance counters.
By default the access from user mode is disabled. You will need to enable it using a kernel module.

We have included on here that you can install
```
cd enable_ccr
make install
```