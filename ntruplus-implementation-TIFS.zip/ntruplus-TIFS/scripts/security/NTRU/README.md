1. Install PARI/GP

sudo apt-get install pari-gp

2. Run the estimation code

gp -q params.gp
