#ifndef UTIL_H
#define UTIL_H

#include <stdint.h>

uint32_t load32_littleendian(const uint8_t x[4]);

#endif