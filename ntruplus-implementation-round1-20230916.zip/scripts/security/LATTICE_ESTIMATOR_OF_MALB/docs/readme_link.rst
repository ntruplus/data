Introduction
============
.. Ignore the title from the README when importing 
   as we have written our own one above

.. include:: ../README.rst
    :start-line: 3
