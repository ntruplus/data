# NTRU+ KS 참조 구현 및 KAT

## 구성
- NTRU+768/, NTRU+864/, NTRU+1152/: 파라미터별 C reference 구현과 시험 프로그램
- KAT/: 각 파라미터의 요청(.req) 및 응답(.rsp) 파일, 각각 100개 시험 사례
- LICENSE: 원본 라이선스

KAT는 키 생성, 캡슐화, 디캡슐화의 KEM 입출력을 확인하는 자료입니다. 모든 보조 알고리즘에 대한 개별 KAT를 뜻하지 않습니다.

## 빌드 및 실행
Linux 또는 MSYS2 환경에서 make와 GCC(또는 Clang)를 사용합니다. 각 파라미터 폴더에서 실행합니다.

```sh
make CC=gcc
./build/test
./build/PQCgenKAT_kem
```

생성된 PQCkemKAT_*.req 및 PQCkemKAT_*.rsp를 KAT의 해당 파라미터 폴더와 비교합니다. Windows와 Linux의 줄바꿈 차이는 제외하고 비교할 수 있습니다.

## 출처
- 저장소: https://github.com/ntruplus/ntruplus
- 기준 커밋: 3991b2ae08d6f0008d37e41b8aceaaab27b4ec89
- 작성일: 2026-10-16

Reference_Implementation과 KAT를 기준 커밋에서 추출했습니다. 공통 파일을 가리키는 심볼릭 링크는 실제 파일과 폴더로 풀어 독립적으로 빌드할 수 있게 했습니다. 원본 소스와 KAT의 내용은 변경하지 않았습니다.
