#ifndef NTT_H
#define NTT_H

#include <stdint.h>
#include "params.h"

#if   NTRUPLUS_N == 768
  #define NTRUPLUS_ZETAS_LEN 192
  extern const int16_t ntruplus_ref_zetas_768[NTRUPLUS_ZETAS_LEN];
  #define zetas ntruplus_ref_zetas_768
#elif NTRUPLUS_N == 864 || NTRUPLUS_N == 1152
  #define NTRUPLUS_ZETAS_LEN 288
  extern const int16_t ntruplus_ref_zetas_864_1152[NTRUPLUS_ZETAS_LEN];
  #define zetas ntruplus_ref_zetas_864_1152
#else
  #error "Unsupported NTRUPLUS_N"
#endif

#define ntt NTRUPLUS_NAMESPACE(ntt)
void ntt(int16_t r[NTRUPLUS_N], const int16_t a[NTRUPLUS_N]);
#define invntt NTRUPLUS_NAMESPACE(invntt)
void invntt(int16_t r[NTRUPLUS_N], const int16_t a[NTRUPLUS_N]);
#define baseinv NTRUPLUS_NAMESPACE(baseinv)
int  baseinv(int16_t r[NTRUPLUS_D], const int16_t a[NTRUPLUS_D], const int16_t zeta);
#define basemul NTRUPLUS_NAMESPACE(basemul)
void basemul(int16_t r[NTRUPLUS_D], const int16_t a[NTRUPLUS_D], const int16_t b[NTRUPLUS_D], const int16_t zeta);
#define basemul_add NTRUPLUS_NAMESPACE(basemul_add)
void basemul_add(int16_t r[NTRUPLUS_D], const int16_t a[NTRUPLUS_D], const int16_t b[NTRUPLUS_D], const int16_t c[NTRUPLUS_D], const int16_t zeta);
#endif
