#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "../api.h"
#include "counter.h"

#define TEST_LOOP 100000
#define TITLE_WIDTH 50

static void print_title(const char *title)
{
    size_t len = strlen(title);
    size_t total = TITLE_WIDTH;
    size_t left = 0;
    size_t right = 0;

    if (len + 2 > total) {
        total = len + 2;
    }

    if (len + 2 <= total) {
        left = (total - (len + 2)) / 2;
        right = total - (len + 2) - left;
    }

    for (size_t i = 0; i < left; i++) printf("=");
    printf(" %s ", title);
    for (size_t i = 0; i < right; i++) printf("=");
    printf("\n");
}

static void print_rule(void)
{
    for (size_t i = 0; i < TITLE_WIDTH; i++) printf("=");
    printf("\n");
}

typedef int (*kem_keypair_fn)(uint8_t *pk, uint8_t *sk);
typedef int (*kem_enc_fn)(uint8_t *ct, uint8_t *ss, const uint8_t *pk);
typedef int (*kem_dec_fn)(uint8_t *ss, const uint8_t *ct, const uint8_t *sk);

typedef struct {
    const char *name;
    const char *algname;
    size_t pk_bytes;
    size_t sk_bytes;
    size_t ct_bytes;
    size_t ss_bytes;
    kem_keypair_fn keypair;
    kem_enc_fn enc;
    kem_dec_fn dec;
} kem_params;

static void print_params(const kem_params *params)
{
    print_title("PARAMETERS");
    printf(" ALGORITHM_NAME  : %s\n", params->algname);
    printf(" PUBLICKEYBYTES  : %zu\n", params->pk_bytes);
    printf(" SECRETKEYBYTES  : %zu\n", params->sk_bytes);
    printf(" CIPHERTEXTBYTES : %zu\n", params->ct_bytes);
    print_rule();
}

static int test_kem(const kem_params *params)
{
    uint8_t pk[2048] = {0};
    uint8_t sk[4096] = {0};
    uint8_t ct[2048] = {0};
    uint8_t ss[64] = {0};
    uint8_t dss[64] = {0};

    if (params->pk_bytes > sizeof pk || params->sk_bytes > sizeof sk ||
        params->ct_bytes > sizeof ct || params->ss_bytes > sizeof ss) {
        printf("%s: size overflow\n", params->name);
        return 1;
    }

    print_title("CORRECTNESS TEST");

    //Generate public and secret key
    params->keypair(pk, sk);

    int cnt = 0;
    for (int j = 0; j < TEST_LOOP; j++) {
        params->enc(ct, ss, pk);
        params->dec(dss, ct, sk);
        if (memcmp(ss, dss, params->ss_bytes) != 0) {
            printf("ss[%d]  : ", j);
            for (size_t i = 0; i < params->ss_bytes; i++) printf("%02X", ss[i]);
            printf("\n");

            printf("dss[%d] : ", j);
            for (size_t i = 0; i < params->ss_bytes; i++) printf("%02X", dss[i]);
            printf("\n");

            cnt++;
        }
    }

    printf(" count: %d\n", cnt);
    print_rule();
    return cnt != 0;
}

static void test_kem_clock(const kem_params *params)
{
    uint8_t pk[2048] = {0};
    uint8_t sk[4096] = {0};
    uint8_t ct[2048] = {0};
    uint8_t ss[64] = {0};
    uint8_t dss[64] = {0};

    if (params->pk_bytes > sizeof pk || params->sk_bytes > sizeof sk ||
        params->ct_bytes > sizeof ct || params->ss_bytes > sizeof ss) {
        printf("%s: size overflow\n", params->name);
        return;
    }

    unsigned long long kcounts = 0;
    unsigned long long ecounts = 0;
    unsigned long long dcounts = 0;
    unsigned long long count1, count2;

    print_title("SPEED TEST");

    for (int i = 0; i < TEST_LOOP; i++) {
        count1 = counter();
        params->keypair(pk, sk);
        count2 = counter();
        kcounts += count2 - count1 - countergap;
    }
#if defined(__aarch64__)
    printf("  KEYGEN runs in ................. %8llu ticks\n", kcounts / TEST_LOOP);
#else
    printf("  KEYGEN runs in ................. %8llu cycles\n", kcounts / TEST_LOOP);
#endif

    for (int i = 0; i < TEST_LOOP; i++) {
        count1 = counter();
        params->enc(ct, ss, pk);
        count2 = counter();
        ecounts += count2 - count1 - countergap;

        count1 = counter();
        params->dec(dss, ct, sk);
        count2 = counter();
        dcounts += count2 - count1 - countergap;
    }

#if defined(__aarch64__)
    printf("  ENCAP  runs in ................. %8llu ticks\n", ecounts / TEST_LOOP);
    printf("  DECAP  runs in ................. %8llu ticks\n", dcounts / TEST_LOOP);
#else
    printf("  ENCAP  runs in ................. %8llu cycles\n", ecounts / TEST_LOOP);
    printf("  DECAP  runs in ................. %8llu cycles\n", dcounts / TEST_LOOP);
#endif
    print_rule();
}

int main(void)
{
    const kem_params params[] = {
        {
            "NTRU+768",
            ntruplus768_ALGNAME,
            ntruplus768_PUBLICKEYBYTES,
            ntruplus768_SECRETKEYBYTES,
            ntruplus768_CIPHERTEXTBYTES,
            ntruplus768_BYTES,
            ntruplus768_ref_keypair,
            ntruplus768_ref_enc,
            ntruplus768_ref_dec,
        },
        {
            "NTRU+864",
            ntruplus864_ALGNAME,
            ntruplus864_PUBLICKEYBYTES,
            ntruplus864_SECRETKEYBYTES,
            ntruplus864_CIPHERTEXTBYTES,
            ntruplus864_BYTES,
            ntruplus864_ref_keypair,
            ntruplus864_ref_enc,
            ntruplus864_ref_dec,
        },
        {
            "NTRU+1152",
            ntruplus1152_ALGNAME,
            ntruplus1152_PUBLICKEYBYTES,
            ntruplus1152_SECRETKEYBYTES,
            ntruplus1152_CIPHERTEXTBYTES,
            ntruplus1152_BYTES,
            ntruplus1152_ref_keypair,
            ntruplus1152_ref_enc,
            ntruplus1152_ref_dec,
        },
    };
    int failed = 0;

    print_title("BENCHMARK INFO");
    setup_counter();
    printf("ITERATIONS: %d\n", TEST_LOOP);
    print_rule();
    printf("\n");

    for (size_t i = 0; i < sizeof params / sizeof params[0]; i++) {
        const kem_params *p = &params[i];
        print_params(p);
        failed |= test_kem(p);
        test_kem_clock(p);
        printf("\n");
    }

    return failed;
}
