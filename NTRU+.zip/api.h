#ifndef API_H
#define API_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define ntruplus768_SECRETKEYBYTES 2336
#define ntruplus768_PUBLICKEYBYTES 1152
#define ntruplus768_CIPHERTEXTBYTES 1152
#define ntruplus768_BYTES 32
#define ntruplus768_ALGNAME "NTRU+768"

int ntruplus768_ref_keypair(uint8_t *pk, uint8_t *sk);
int ntruplus768_ref_enc(uint8_t *ct, uint8_t *ss, const uint8_t *pk);
int ntruplus768_ref_dec(uint8_t *ss, const uint8_t *ct, const uint8_t *sk);

#define ntruplus864_SECRETKEYBYTES 2624
#define ntruplus864_PUBLICKEYBYTES 1296
#define ntruplus864_CIPHERTEXTBYTES 1296
#define ntruplus864_BYTES 32
#define ntruplus864_ALGNAME "NTRU+864"

int ntruplus864_ref_keypair(uint8_t *pk, uint8_t *sk);
int ntruplus864_ref_enc(uint8_t *ct, uint8_t *ss, const uint8_t *pk);
int ntruplus864_ref_dec(uint8_t *ss, const uint8_t *ct, const uint8_t *sk);

#define ntruplus1152_SECRETKEYBYTES 3488
#define ntruplus1152_PUBLICKEYBYTES 1728
#define ntruplus1152_CIPHERTEXTBYTES 1728
#define ntruplus1152_BYTES 32
#define ntruplus1152_ALGNAME "NTRU+1152"

int ntruplus1152_ref_keypair(uint8_t *pk, uint8_t *sk);
int ntruplus1152_ref_enc(uint8_t *ct, uint8_t *ss, const uint8_t *pk);
int ntruplus1152_ref_dec(uint8_t *ss, const uint8_t *ct, const uint8_t *sk);

#ifdef __cplusplus
}
#endif

#endif
