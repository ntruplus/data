#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "api.h"
#include "randombytes.h"
#include "poly.h"
#include "symmetric.h"
#include "cpucycles.h"

#define TEST_LOOP 100000

static void TEST_CCA_KEM(void)
{
	unsigned char pk[CRYPTO_PUBLICKEYBYTES] = {0};
	unsigned char sk[CRYPTO_SECRETKEYBYTES] = {0};
	unsigned char ct[CRYPTO_CIPHERTEXTBYTES] = {0};
	unsigned char ss[CRYPTO_BYTES] = {0};
	unsigned char dss[CRYPTO_BYTES] = {0};

	int cnt = 0;

	printf("============ CCA_KEM ENCAP DECAP TEST ============\n");

	//Generate public and secret key
	crypto_kem_keypair(pk, sk);

	//Encrypt and Decrypt message
	for(int j = 0; j < TEST_LOOP; j++)
	{
		crypto_kem_enc(ct, ss, pk);
		crypto_kem_dec(dss, ct, sk);

		if(memcmp(ss, dss, 32) != 0)
		{
			printf("ss[%d]  : ", j);
			for(int i=0; i<32; i++) printf("%02X", ss[i]);
			printf("\n");
		
			printf("dss[%d] : ", j);
			for(int i=0; i<32; i++) printf("%02X", dss[i]);
			printf("\n");
		
			cnt++;
		}
	}
	printf("count: %d\n", cnt);
	printf("==================================================\n\n");

}

static void TEST_CCA_KEM_CLOCK(void)
{
	unsigned char pk[CRYPTO_PUBLICKEYBYTES] = {0};
	unsigned char sk[CRYPTO_SECRETKEYBYTES] = {0};
	unsigned char ct[CRYPTO_CIPHERTEXTBYTES] = {0};
	unsigned char ss[CRYPTO_BYTES] = {0};
	unsigned char dss[CRYPTO_BYTES] = {0};

	unsigned long long kcycles, ecycles, dcycles;
	unsigned long long cycles1, cycles2;
	
	printf("========= CCA KEM ENCAP DECAP SPEED TEST =========\n");
	
	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		crypto_kem_keypair(pk, sk);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  KEYGEN runs in ................. %8lld cycles", kcycles/TEST_LOOP);
	printf("\n"); 
	
	ecycles=0;
	dcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		crypto_kem_enc(ct, ss, pk);
		cycles2 = cpucycles();
		ecycles += cycles2-cycles1-cyclegap;
		
		cycles1 = cpucycles(); 
		crypto_kem_dec(dss, ct, sk);
		cycles2 = cpucycles();
		dcycles += cycles2-cycles1-cyclegap;
	}
	
	printf("  ENCAP  runs in ................. %8lld cycles", ecycles/TEST_LOOP);
	printf("\n"); 
	
	printf("  DECAP  runs in ................. %8lld cycles", dcycles/TEST_LOOP);
	printf("\n"); 
	
	printf("==================================================\n\n");
}

static void TEST_MODULE_CLOCK(void)
{
	unsigned char buf[10000] = {0};

	poly a,b,c;
	unsigned long long kcycles;
	unsigned long long cycles1, cycles2;
	
	printf("================ MODULE SPEED TEST ===============\n");
	
	for (int i = 0; i < NTRUPLUS_N; i++)
	{
		a.coeffs[i] = b.coeffs[i] = c.coeffs[i] = 0;
	}
	a.coeffs[0] = 1;
	poly_ntt(&b,&a);
	
	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		poly_baseinv(&a, &b);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  poly_baseinv runs in ........... %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		poly_invntt(&a, &a);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  poly_invntt runs in ............ %8lld cycles", kcycles/TEST_LOOP);
	printf("\n"); 

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		poly_basemul_add(&a, &a, &a, &a);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  poly_basemul_add runs in ....... %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		poly_basemul(&a, &a, &a);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  poly_basemul runs in ........... %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		poly_ntt(&a, &a);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  poly_ntt runs in ............... %8lld cycles", kcycles/TEST_LOOP);
	printf("\n"); 

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		poly_sotp_decode(buf, &a, buf);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  poly_sotp_decode runs in ....... %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		poly_tobytes(buf, &a);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  poly_tobytes runs in ........... %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");
	
	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		poly_sotp_encode(&a, buf, buf);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  poly_sotp_encode runs in ....... %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		poly_cbd1(&a, buf);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  poly_cbd1 runs in .............. %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");	

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		poly_frombytes(&a, buf);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  poly_frombytes runs in ......... %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		poly_crepmod3(&a, &a);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  poly_crepmod3 runs in .......... %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		poly_triple(&a, &a);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  poly_triple runs in ............ %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		poly_sub(&a, &a, &a);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  poly_sub runs in ............... %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		hash_g(buf, buf);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  hash_g runs in ................. %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		hash_f(buf, buf);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  hash_f runs in ................. %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");

	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		hash_h(buf, buf);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  hash_h runs in ................. %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");
		
	kcycles=0;
	for (int i = 0; i < TEST_LOOP; i++)
	{
		cycles1 = cpucycles();
		randombytes(buf, NTRUPLUS_N / 8);
		cycles2 = cpucycles();
		kcycles += cycles2-cycles1-cyclegap;
	}
	printf("  randombytes runs in ............ %8lld cycles", kcycles/TEST_LOOP);
	printf("\n");
	printf("==================================================\n\n");
}

int main(void)
{
	printf("================= BENCHMARK INFO =================\n");
	setup_rdtsc();
	printf("cyclegap: %lld\n",cyclegap);
	printf("==================================================\n\n");

	printf("=================== PARAMETERS ===================\n");
	printf("ALGORITHM_NAME  : %s\n", CRYPTO_ALGNAME);
	printf("PUBLICKEYBYTES : %d\n", CRYPTO_PUBLICKEYBYTES);
	printf("SECRETKEYBYTES : %d\n", CRYPTO_SECRETKEYBYTES);
	printf("CIPHERTEXTBYTES : %d\n", CRYPTO_CIPHERTEXTBYTES);
	printf("==================================================\n\n");

	TEST_CCA_KEM();
	TEST_CCA_KEM_CLOCK();
	TEST_MODULE_CLOCK();

	return 0;	
}
